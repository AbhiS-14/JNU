const {models,transaction}=require('../db');const {AppError}=require('../errors');const {getTeamForUser}=require('./identity');const {audit}=require('./audit');const {recordProgress}=require('./participantProgress');
async function getMyMatches(user){
  const team=await getTeamForUser(user.id);
  if(!team)return[];
  const list=await models.Match.find({'participants.team_id':team.id}).sort({match_number:1}).lean();
  if(!list.length)return[];
  // Fetch related records in batches instead of issuing two queries per match.
  const opponentIds=[...new Set(list.flatMap(match=>match.participants.filter(p=>p.team_id!==team.id).map(p=>p.team_id)))];
  const problemIds=[...new Set(list.map(match=>match.problem_id).filter(Boolean))];
  const [opponents,problems]=await Promise.all([
    opponentIds.length?models.Team.find({_id:{$in:opponentIds}}).select('_id name').lean():[],
    problemIds.length?models.Problem.find({_id:{$in:problemIds}}).select('_id title difficulty').lean():[],
  ]);
  const opponentById=new Map(opponents.map(item=>[item._id,item]));
  const problemById=new Map(problems.map(item=>[item._id,item]));
  return list.map(m=>{
    const own=m.participants.find(p=>p.team_id===team.id);
    const other=m.participants.find(p=>p.team_id!==team.id);
    const opponent=other?opponentById.get(other.team_id):null;
    const problem=m.problem_id?problemById.get(m.problem_id):null;
    return{id:m._id,match_number:m.match_number,state:m.state,duration_seconds:m.duration_seconds,started_at:m.started_at,ends_at:m.ends_at,attack_closes_at:m.attack_closes_at,remaining_seconds:m.remaining_seconds,problem_id:m.problem_id,problem_title:problem?.title,difficulty:problem?.difficulty,role:own?.role,score:own?.score,opponent_name:opponent?.name};
  });
}
async function getMatch(user,matchId,admin=false){const team=admin?null:await getTeamForUser(user.id);const m=await models.Match.findOne({_id:matchId,...(admin?{}:{'participants.team_id':team?.id})}).lean();if(!m)throw new AppError(404,'Match not found.','MATCH_NOT_FOUND');const problem=m.problem_id?await models.Problem.findById(m.problem_id).lean():null;const own=m.participants.find(p=>admin||p.team_id===team?.id);const other=m.participants.find(p=>p.team_id!==own?.team_id);const [ownTeam,opponent]=await Promise.all([own?models.Team.findById(own.team_id).select('name').lean():null,other?models.Team.findById(other.team_id).select('name').lean():null]);const visible=admin?{...m}:{_id:m._id,tournament_id:m.tournament_id,round_id:m.round_id,match_number:m.match_number,state:m.state,duration_seconds:m.duration_seconds,started_at:m.started_at,ends_at:m.ends_at,attack_closes_at:m.attack_closes_at,remaining_seconds:m.remaining_seconds,winner_team_id:m.winner_team_id,winner_role:m.winner_role,result:m.result?.reason?{reason:m.result.reason}:{},version:m.version};return{...visible,id:m._id,problem_title:problem?.title,problem_description:problem?.description,difficulty:problem?.difficulty,input_format:problem?.input_format,output_format:problem?.output_format,constraints_text:problem?.constraints_text,starter_code:problem?.starter_code,allowed_languages:problem?.allowed_languages,time_limit_ms:problem?.time_limit_ms,memory_limit_mb:problem?.memory_limit_mb,own_team_id:own?.team_id,own_role:own?.role,own_team_name:ownTeam?.name,opponent_team_id:other?.team_id,opponent_team_name:opponent?.name,opponent_role:other?.role,source_code:m.code?.source_code,language:m.code?.language,revision:m.code?.revision}}
async function startMatch(admin,id){const match=await transaction(async session=>{const m=await models.Match.findById(id).session(session);if(!m)throw new AppError(404,'Match not found.');if(!['WAITING','READY','PAUSED'].includes(m.state))throw new AppError(409,'Match cannot start from its current state.');if(!m.problem_id)throw new AppError(409,'Assign an active challenge before starting.');const problem=await models.Problem.findOne({_id:m.problem_id,is_active:true}).session(session).lean();if(!problem)throw new AppError(409,'The assigned challenge is no longer active. Assign an active challenge before starting.');const tournament=await models.Tournament.findById(m.tournament_id).session(session).lean();const duration=m.remaining_seconds||m.duration_seconds||tournament?.config?.matchDurationSeconds||900;const now=new Date();const attackWindow={easy:130,medium:210,hard:336}[problem?.difficulty]||Math.floor(duration*0.7);const attackRemaining=m.attack_remaining_seconds??attackWindow;m.state='ACTIVE';m.started_at=now;m.ends_at=new Date(now.getTime()+duration*1000);m.attack_closes_at=new Date(now.getTime()+Math.min(duration,attackRemaining)*1000);m.attack_remaining_seconds=null;m.paused_at=null;m.remaining_seconds=null;m.version++;await m.save({session});await models.AuditLog.create([{actor_id:admin.id,action:'match.started',resource_type:'match',resource_id:id}],{session});return m.toObject()});return getMatch(admin,id,true)}
async function pauseMatch(admin,id){await transaction(async session=>{const m=await models.Match.findById(id).session(session);if(!m)throw new AppError(404,'Match not found.');if(m.state!=='ACTIVE')throw new AppError(409,'Only active matches can be paused.');m.remaining_seconds=Math.max(0,Math.floor((m.ends_at-Date.now())/1000));m.attack_remaining_seconds=m.attack_closes_at?Math.max(0,Math.floor((m.attack_closes_at-Date.now())/1000)):0;m.state='PAUSED';m.paused_at=new Date();m.ends_at=null;m.attack_closes_at=null;m.version++;await m.save({session});await models.AuditLog.create([{actor_id:admin.id,action:'match.paused',resource_type:'match',resource_id:id}],{session})});return getMatch(admin,id,true)}
async function endMatch(admin,id,winnerTeamId,reason='admin_override'){return transaction(async session=>{const m=await models.Match.findById(id).session(session);if(!m)throw new AppError(404,'Match not found.');if(winnerTeamId&&!m.participants.some(p=>p.team_id===winnerTeamId))throw new AppError(400,'Winner must be a team in this match.');const winning=m.participants.find(p=>p.team_id===winnerTeamId);m.state='COMPLETED';m.winner_team_id=winnerTeamId||null;m.winner_role=winning?.role||null;m.result={reason,overriddenBy:admin.id};m.ends_at=null;m.version++;for(const p of m.participants)p.outcome=p.team_id===winnerTeamId?'win':'loss';if(winning){const tournament=await models.Tournament.findById(m.tournament_id).session(session).lean();const points=Number(tournament?.config?.scoring?.[winning.role==='CODER'?'coderWin':'detectiveWin']??100);winning.score+=points;await models.Score.create([{tournament_id:m.tournament_id,team_id:winnerTeamId,match_id:id,points,category:'match_win',details:{reason}}],{session})}await m.save({session});await models.AuditLog.create([{actor_id:admin.id,action:'match.completed',resource_type:'match',resource_id:id,metadata:{winnerTeamId,reason}}],{session});return m.toObject()})}
async function syncCode(user,matchId,sourceCode,language){
  if(typeof sourceCode!=='string'||sourceCode.length>50000)throw new AppError(400,'Code must be 50,000 characters or less.');
  const saved=await transaction(async session=>{
    const team=await getTeamForUser(user.id);
    if(!team)throw new AppError(403,'Participant team required.');
    const match=await models.Match.findOne({_id:matchId,'participants.team_id':team.id}).session(session);
    if(!match)throw new AppError(404,'Match not found.');
    const participant=match.participants.find(entry=>entry.team_id===team.id);
    if(participant.role!=='CODER')throw new AppError(403,'Only the coder team may edit this solution.');
    if(match.state!=='ACTIVE'||!match.ends_at||match.ends_at<=new Date())throw new AppError(409,'Code editing is closed for this match.');
    const problem=await models.Problem.findById(match.problem_id).session(session).lean();
    if(!problem?.allowed_languages.includes(language))throw new AppError(400,'Language is not allowed for this problem.');
    match.code.source_code=sourceCode;
    match.code.language=language;
    match.code.revision++;
    match.code.updated_at=new Date();
    await match.save({session});
    await recordProgress(user.id,matchId,{type:'code_saved',sourceCode,language,revision:match.code.revision,detail:{revision:match.code.revision}},{team,match,session});
    return{revision:match.code.revision};
  });
  return saved;
}
async function expireMatch(row){return transaction(async session=>{const m=await models.Match.findById(row.id||row._id).session(session);if(!m||m.state!=='ACTIVE'||!m.ends_at||m.ends_at>Date.now())return null;const winner=m.participants.find(p=>p.role==='DETECTIVE');const coder=m.participants.find(p=>p.role==='CODER');m.state='COMPLETED';m.winner_team_id=winner?.team_id||null;m.winner_role='DETECTIVE';m.result={reason:'timeout'};m.version++;for(const p of m.participants)p.outcome=p.team_id===winner?.team_id?'win':'loss';if(winner){const t=await models.Tournament.findById(m.tournament_id).session(session).lean();const points=Number(t?.config?.scoring?.detectiveWin??100);winner.score+=points;await models.Score.create([{tournament_id:m.tournament_id,team_id:winner.team_id,match_id:m._id,points,category:'detective_win',details:{}}],{session})}await m.save({session});return{...m.toObject(),coder_team_id:coder?.team_id}})}
module.exports={getMyMatches,getMatch,startMatch,pauseMatch,endMatch,syncCode,expireMatch};
